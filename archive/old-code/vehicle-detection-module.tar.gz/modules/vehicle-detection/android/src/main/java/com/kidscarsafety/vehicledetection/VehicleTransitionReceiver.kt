package com.kidscarsafety.vehicledetection

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionResult
import com.google.android.gms.location.DetectedActivity

/**
 * המקלט שגוגל מעירה כשההורה נכנס לרכב או יוצא ממנו.
 *
 * רץ בתהליך קצר משלו, גם כשהאפליקציה סגורה לגמרי. לכן כל מה שצריך לקרות
 * ברגע היציאה מהרכב חייב לקרות כאן, בקוד נייטיב - כולל שליחת ההתראה עצמה.
 */
class VehicleTransitionReceiver : BroadcastReceiver() {

  companion object {
    const val CHANNEL_ID = "vehicle-exit"
    const val NOTIFICATION_ID = 4711
    const val EXTRA_FROM_DETECTION = "from_vehicle_detection"
  }

  override fun onReceive(context: Context, intent: Intent) {
    if (!ActivityTransitionResult.hasResult(intent)) return
    val result = ActivityTransitionResult.extractResult(intent) ?: return

    for (event in result.transitionEvents) {
      if (event.activityType != DetectedActivity.IN_VEHICLE) continue

      when (event.transitionType) {
        ActivityTransition.ACTIVITY_TRANSITION_ENTER -> {
          // נכנס לרכב: רק רושמים. אין טעם להפריע להורה בהתראה עכשיו -
          // האפליקציה תפתח נסיעה בשקט כשהיא תתעורר.
          VehicleDetectionStore.recordEvent(
            context, VehicleDetectionStore.EVENT_ENTER, System.currentTimeMillis()
          )
        }

        ActivityTransition.ACTIVITY_TRANSITION_EXIT -> {
          // יצא מהרכב: זה הרגע שכל המוצר קיים בשבילו.
          VehicleDetectionStore.recordEvent(
            context, VehicleDetectionStore.EVENT_EXIT, System.currentTimeMillis()
          )
          notifyExitedVehicle(context)
        }
      }
    }
  }

  private fun notifyExitedVehicle(context: Context) {
    createChannel(context)

    // לחיצה על ההתראה פותחת את האפליקציה. היא תקרא בעצמה מה קרה
    // (דרך VehicleDetectionStore) ותנווט למסך בדיקת הבטיחות.
    val launchIntent = context.packageManager
      .getLaunchIntentForPackage(context.packageName)
      ?.apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        putExtra(EXTRA_FROM_DETECTION, true)
      }

    val pendingIntent = launchIntent?.let {
      PendingIntent.getActivity(
        context,
        0,
        it,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
    }

    val iconId = context.resources.getIdentifier(
      "notification_icon", "drawable", context.packageName
    ).takeIf { it != 0 } ?: android.R.drawable.ic_dialog_info

    val builder = NotificationCompat.Builder(context, CHANNEL_ID)
      .setSmallIcon(iconId)
      .setContentTitle("עוצרים רגע")
      .setContentText("יצאת מהרכב — בדקת שכל הילדים יצאו?")
      .setStyle(
        NotificationCompat.BigTextStyle()
          .bigText("יצאת מהרכב — בדקת שכל הילדים יצאו? הקש כדי לאשר.")
      )
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setCategory(NotificationCompat.CATEGORY_ALARM)
      .setAutoCancel(true)

    if (pendingIntent != null) builder.setContentIntent(pendingIntent)

    try {
      NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build())
    } catch (e: SecurityException) {
      // באנדרואיד 13 ומעלה ההורה יכול לסרב להרשאת התראות.
      // לא מקריסים - האירוע כבר נרשם, והאפליקציה תציג את הבדיקה בפתיחה הבאה.
    }
  }

  private fun createChannel(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val channel = NotificationChannel(
      CHANNEL_ID,
      "יציאה מהרכב",
      NotificationManager.IMPORTANCE_HIGH
    ).apply {
      description = "התראה ברגע שזוהתה יציאה מהרכב"
      enableVibration(true)
    }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.createNotificationChannel(channel)
  }
}
