import { router } from 'expo-router';
import { AutoTripSnapshot } from '../models/TripState';
import { Trip } from '../models';
import { TripStorage } from '../storage';
import * as tripStateService from './tripStateService';
import * as locationService from './locationService';
import * as vehicleDetection from '../../modules/vehicle-detection';
import {
  scheduleImmediateWarning,
  scheduleSecondWarning,
} from '../notifications/notificationService';
import { logEvent, TripEventName } from './eventLog';

/**
 * מדליק ומכבה את ההגנה האוטומטית, ומחבר את מכונת המצבים לעולם האמיתי:
 * התראות, ניווט, ושמירת נסיעות להיסטוריה.
 *
 * הכל כאן עמיד לכישלון בכוונה: אם ההרשאות חסרות או שהמודול הנייטיב לא
 * קיים, הפונקציות פשוט מחזירות false. אף פעם לא מקריסים את האפליקציה
 * בגלל שההגנה האוטומטית לא זמינה - המצב הידני חייב להמשיך לעבוד.
 */

let started = false;

function toTrip(snapshot: AutoTripSnapshot): Trip {
  const startedAt = snapshot.tripStartedAt ?? snapshot.stateSince;
  return {
    id: `trip_${startedAt}_${Math.random().toString(36).slice(2, 8)}`,
    startTime: new Date(startedAt).toISOString(),
    endTime: snapshot.stopLocation
      ? new Date(snapshot.stopLocation.stoppedAt).toISOString()
      : new Date().toISOString(),
    confirmedAt: snapshot.confirmedSafeAt
      ? new Date(snapshot.confirmedSafeAt).toISOString()
      : undefined,
    status: 'CONFIRMED',
    childrenIds: [],
    // סעיף 34: מתעדים אם הופעלה אזהרה, כדי שההורה יראה את זה בהיסטוריה.
    remindersSent: snapshot.secondWarningAt ? 2 : snapshot.firstWarningAt ? 1 : 0,
    skippedSafetyCheck: false,
  };
}

const handlers: tripStateService.Handlers = {
  onFirstWarning: async () => {
    await scheduleImmediateWarning();
    // אם האפליקציה פתוחה - מקפיצים את ההורה ישר למסך האזהרה.
    try {
      router.push('/warning');
    } catch {
      // האפליקציה ברקע. ההתראה תביא אותו לכאן כשילחץ עליה.
    }
  },
  onSecondWarning: async () => {
    await scheduleSecondWarning();
  },
  onEscalation: async () => {
    logEvent(TripEventName.ESCALATION_STARTED);
    try {
      router.push('/warning');
    } catch {
      // כנ"ל.
    }
  },
  onPersistTrip: async (snapshot) => {
    await TripStorage.saveTrip(toTrip(snapshot));
  },
};

/**
 * מדליק את ההגנה. מחזיר תיאור של מה באמת הופעל, כדי שמסך הבית
 * יוכל להציג להורה מצב אמיתי ולא הבטחה.
 */
export async function startProtection(): Promise<{
  location: boolean;
  motion: boolean;
}> {
  tripStateService.setHandlers(handlers);
  tripStateService.startEngine();
  started = true;

  const location = await locationService.startTracking();
  const motion = await vehicleDetection.startTracking();

  logEvent(TripEventName.PERMISSION_CHANGED, `הגנה: מיקום=${location}, תנועה=${motion}`);
  return { location, motion };
}

export async function stopProtection(): Promise<void> {
  tripStateService.stopEngine();
  await locationService.stopTracking();
  await vehicleDetection.stopTracking();
  started = false;
}

export function isStarted(): boolean {
  return started;
}

/**
 * נקרא בכל פתיחה של האפליקציה.
 *
 * המודול הנייטיב רושם אירועים גם כשהאפליקציה סגורה לגמרי - זה בדיוק
 * המקרה שבו ההורה יצא מהרכב והאפליקציה לא רצה. כאן אנחנו קוראים את
 * מה שקרה בזמן שלא היינו ומגיבים אליו.
 */
export async function consumePendingVehicleEvent(): Promise<void> {
  const pending = vehicleDetection.getPendingEvent();
  if (!pending) return;

  vehicleDetection.clearPendingEvent();

  if (pending.type === 'EXIT_VEHICLE') {
    await tripStateService.onVehicleExit(locationService.getLastSample());
  } else if (pending.type === 'ENTER_VEHICLE') {
    await tripStateService.onVehicleEnter();
  }
}
