import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { Trip, ReminderSettings } from '../models';
import { getReminderDefs, getTripStartNotificationDefs } from './reminderLogic';

export { isReminderDeadlinePassed, getTripActiveReminderMinutes } from './reminderLogic';

/**
 * בונה טריגר של "עוד X דקות".
 *
 * חשוב: גרסאות חדשות של expo-notifications דורשות שדה type מפורש בטריגר.
 * בלעדיו הקריאה נכשלת וההתראה פשוט לא מתוזמנת - בשקט, כי השגיאה נבלעת
 * ב-try/catch. זו הסיבה שהתזכורות המושהות לא הגיעו אף פעם, בעוד שההתראות
 * המיידיות (trigger: null) עבדו כרגיל.
 */
function minutesFromNow(minutes: number): Notifications.NotificationTriggerInput {
  return {
    type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
    seconds: Math.max(1, Math.round(minutes * 60)),
    repeats: false,
  };
}

/** לוג עזר בפיתוח: כמה התראות באמת ממתינות כרגע במערכת. */
async function logPendingCount(context: string): Promise<void> {
  if (!__DEV__) return;
  try {
    const pending = await Notifications.getAllScheduledNotificationsAsync();
    console.log(`[notifications] ${context}: ${pending.length} התראות ממתינות`);
  } catch {
    // לוג בלבד - לא משנה אם נכשל.
  }
}

// איך ההתראה מוצגת כשהאפליקציה פתוחה ברקע (חובה להגדיר, אחרת iOS/Android
// לא בהכרח מציגים אותה כשהאפליקציה ברקע).
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

if (Platform.OS === 'android') {
  Notifications.setNotificationChannelAsync('safety-check', {
    name: 'בדיקת בטיחות',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
  }).catch(() => {
    // לא קריטי אם זה נכשל - עדיין ננסה לשלוח התראות רגילות.
  });
}

/**
 * מבקש הרשאת התראות אם עוד לא נתבקשה. לא מקריס את האפליקציה אם המשתמש
 * מסרב (סעיף 27) - פשוט מחזיר false, וקוראים לפונקציה יכולים להמשיך הלאה
 * בלי תזכורות.
 */
export async function requestNotificationPermission(): Promise<boolean> {
  try {
    // משתמשים ב-granted (בוליאני) ולא ב-status: זה השדה היציב בין הגרסאות,
    // והוא גם מה שנשאר תקין כשההגדרות של המשתמש חלקיות (למשל התראות שקטות).
    const existing = await Notifications.getPermissionsAsync();
    if (existing.granted) return true;
    const requested = await Notifications.requestPermissionsAsync();
    return requested.granted;
  } catch (error) {
    console.warn('[notifications] נכשלה בקשת הרשאה', error);
    return false;
  }
}

/**
 * מתזמן את שלוש התזכורות עבור נסיעה, ומחזיר את מזהי ההתראות כדי שיהיה
 * אפשר לבטל אותן אם המשתמש מאשר לפני שהן נשלחות.
 */
export async function scheduleSafetyCheckReminders(
  trip: Trip,
  settings: ReminderSettings
): Promise<string[]> {
  const granted = await requestNotificationPermission();
  if (!granted) return [];

  const ids: string[] = [];
  for (const reminder of getReminderDefs(settings)) {
    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title: 'עוצרים רגע',
          body: reminder.body,
          sound: settings.soundEnabled,
          data: { tripId: trip.id, target: 'safety-check' },
        },
        trigger: reminder.minutes > 0 ? minutesFromNow(reminder.minutes) : null,
      });
      ids.push(id);
    } catch (error) {
      console.warn('[notifications] נכשל תזמון תזכורת', error);
    }
  }
  await logPendingCount('אחרי תזמון תזכורות בדיקת בטיחות');
  return ids;
}

/**
 * מתזמן את ההתראות של תחילת הנסיעה: התראה מיידית שנשארת במרכז ההתראות,
 * ותזכורת מאוחרת יותר אם הנסיעה עדיין לא הסתיימה. שתיהן מסומנות
 * target: 'active' כדי שלחיצה עליהן תחזיר את המשתמש למסך הנסיעה הפעילה
 * (ומשם הוא יכול לסיים נסיעה), ולא ישר למסך בדיקת הבטיחות.
 */
export async function scheduleTripStartNotifications(
  trip: Trip,
  settings: ReminderSettings
): Promise<string[]> {
  const granted = await requestNotificationPermission();
  if (!granted) return [];

  const ids: string[] = [];
  for (const def of getTripStartNotificationDefs(settings)) {
    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title: def.title,
          body: def.body,
          sound: def.useSound ? settings.soundEnabled : false,
          sticky: def.sticky,
          data: { tripId: trip.id, target: 'active' },
        },
        trigger: def.minutes > 0 ? minutesFromNow(def.minutes) : null,
      });
      ids.push(id);
    } catch (error) {
      console.warn('[notifications] נכשל תזמון התראת תחילת נסיעה', error);
    }
  }
  await logPendingCount('אחרי תזמון התראות תחילת נסיעה');
  return ids;
}

/**
 * מבטל התראות שעוד לא נשלחו, וגם מסיר משורת ההתראות כאלה שכבר נשלחו.
 * שני הצעדים נחוצים: ביטול לבדו משאיר את ההתראה המיידית תלויה על המסך
 * גם אחרי שהמשתמש כבר סיים את הנסיעה או אישר שכולם יצאו.
 */
export async function cancelReminders(ids: string[] | undefined): Promise<void> {
  if (!ids || ids.length === 0) return;
  for (const id of ids) {
    try {
      await Notifications.cancelScheduledNotificationAsync(id);
    } catch {
      // כבר בוטלה או כבר נשלחה - לא קריטי, ממשיכים.
    }
    try {
      await Notifications.dismissNotificationAsync(id);
    } catch {
      // ההתראה לא נמצאת בשורת ההתראות - לא קריטי.
    }
  }
}

/**
 * האזהרה שנשלחת ברגע שזוהתה יציאה מאזור הרכב (סעיף 15).
 *
 * הניסוח מכוון: לא "שכחת ילד ברכב" - המערכת לא יודעת את זה ואסור לה
 * לטעון שהיא יודעת (סעיף 16). רק שאלה שמחזירה את ההורה לבדוק.
 */
export async function scheduleImmediateWarning(): Promise<string | null> {
  const granted = await requestNotificationPermission();
  if (!granted) return null;

  try {
    return await Notifications.scheduleNotificationAsync({
      content: {
        title: 'רגע לפני שאתה ממשיך',
        body: 'הנסיעה עדיין פתוחה. בדקת שכל הילדים יצאו מהרכב?',
        sound: true,
        priority: Notifications.AndroidNotificationPriority.MAX,
        data: { target: 'warning' },
      },
      trigger: null,
    });
  } catch (error) {
    console.warn('[notifications] נכשלה שליחת אזהרה', error);
    return null;
  }
}

/** האזהרה השנייה, כשאין תגובה לראשונה (סעיף 19). */
export async function scheduleSecondWarning(): Promise<string | null> {
  const granted = await requestNotificationPermission();
  if (!granted) return null;

  try {
    return await Notifications.scheduleNotificationAsync({
      content: {
        title: 'חשוב לבדוק את הרכב עכשיו',
        body: 'לא התקבלה תגובה. ייתכן שילד עדיין ברכב.',
        sound: true,
        priority: Notifications.AndroidNotificationPriority.MAX,
        data: { target: 'warning' },
      },
      trigger: null,
    });
  } catch (error) {
    console.warn('[notifications] נכשלה שליחת אזהרה שנייה', error);
    return null;
  }
}

/**
 * מנקה הכל - משמש באיפוס נתונים, כדי שלא תישאר תלויה בטלפון התראה של
 * נסיעה שכבר נמחקה (במיוחד ההתראה ה"דביקה" של תחילת נסיעה ב-Android).
 */
export async function cancelAllNotifications(): Promise<void> {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
  } catch {
    // לא קריטי.
  }
  try {
    await Notifications.dismissAllNotificationsAsync();
  } catch {
    // לא קריטי.
  }
}
