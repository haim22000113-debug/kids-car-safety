import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Linking, AppState } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button } from '../src/components/Button';
import { theme } from '../src/theme';
import * as locationService from '../src/services/locationService';
import * as vehicleDetection from '../../modules/vehicle-detection';
import { requestNotificationPermission } from '../src/notifications/notificationService';

/**
 * מסך ההרשאות (סעיפים 6, 30).
 *
 * מסביר לפני שמבקש, ומבקש בהדרגה. הסבר לפני בקשה הוא לא רק נימוס -
 * גוגל דורשת אותו במפורש כתנאי לאישור אפליקציה שמבקשת מיקום ברקע.
 */
export default function Permissions() {
  const params = useLocalSearchParams<{ fromOnboarding?: string }>();
  const fromOnboarding = params.fromOnboarding === '1';

  const [foreground, setForeground] = useState(false);
  const [background, setBackground] = useState(false);
  const [needsSettings, setNeedsSettings] = useState(false);
  const [notifications, setNotifications] = useState(false);
  const [motion, setMotion] = useState(false);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    const snapshot = await locationService.getPermissions();
    setForeground(snapshot.foreground);
    setBackground(snapshot.background);
    setNeedsSettings(snapshot.needsSettingsForBackground);
    setMotion(await vehicleDetection.hasPermission());
  }, []);

  useEffect(() => {
    void refresh();
    // כשההורה חוזר מהגדרות המערכת, בודקים מחדש מה השתנה.
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') void refresh();
    });
    return () => sub.remove();
  }, [refresh]);

  const askLocation = async () => {
    setBusy(true);
    await locationService.requestForegroundPermission();
    await refresh();
    setBusy(false);
  };

  const askBackground = async () => {
    setBusy(true);
    await locationService.requestBackgroundPermission();
    await refresh();
    setBusy(false);
  };

  const askNotifications = async () => {
    setBusy(true);
    setNotifications(await requestNotificationPermission());
    setBusy(false);
  };

  const askMotion = async () => {
    setBusy(true);
    await vehicleDetection.requestPermission();
    await refresh();
    setBusy(false);
  };

  const done = () => router.replace(fromOnboarding ? '/home' : '/settings');

  const allGood = foreground && background;

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>כדי שההגנה תעבוד</Text>
        <Text style={styles.intro}>
          כדי שההגנה תעבוד גם כשהאפליקציה אינה פתוחה, אנחנו משתמשים במיקום ברקע. המיקום נשמר
          במכשיר שלך בלבד ואינו נשלח לשום מקום.
        </Text>

        <Item
          title="מיקום"
          granted={foreground}
          description="מאפשר לזהות מתי נסיעה מתחילה ומתי היא נעצרת."
          action={<Button title="אפשר מיקום" onPress={askLocation} loading={busy} />}
        />

        <Item
          title="מיקום ברקע"
          granted={background}
          description="בלעדיו ההגנה תעבוד רק כשהאפליקציה פתוחה על המסך."
          action={
            needsSettings && !background ? (
              <>
                <Text style={styles.hint}>
                  במכשיר שלך צריך לבחור &quot;אפשר תמיד&quot; בהגדרות המערכת — אנדרואיד לא מאפשר
                  לבקש את זה מתוך האפליקציה.
                </Text>
                <Button title="פתח הגדרות" variant="ghost" onPress={() => Linking.openSettings()} />
              </>
            ) : (
              <Button title="אפשר מיקום ברקע" variant="ghost" onPress={askBackground} loading={busy} />
            )
          }
        />

        <Item
          title="התראות"
          granted={notifications}
          description="בלעדיהן לא נוכל להתריע לך בזמן אמת."
          action={<Button title="אפשר התראות" variant="ghost" onPress={askNotifications} loading={busy} />}
        />

        {vehicleDetection.isSupported() ? (
          <Item
            title="זיהוי תנועה"
            granted={motion}
            description="מזהה כניסה ויציאה מהרכב בלי להשתמש ב-GPS. חוסך סוללה ומדויק יותר."
            action={<Button title="אפשר זיהוי תנועה" variant="ghost" onPress={askMotion} loading={busy} />}
          />
        ) : null}

        {!allGood ? (
          <View style={styles.limitedBox}>
            <Text style={styles.limitedText}>
              כל עוד ההרשאות חסרות, ההגנה האוטומטית מוגבלת. תמיד אפשר להשתמש במצב הידני —
              &quot;התחל נסיעה&quot; ו&quot;סיים נסיעה&quot; — שעובד בלי שום הרשאת מיקום.
            </Text>
          </View>
        ) : null}
      </ScrollView>

      <View style={styles.footer}>
        <Button title={allGood ? 'מצוין, ממשיכים' : 'המשך בינתיים'} onPress={done} />
      </View>
    </SafeAreaView>
  );
}

function Item({
  title,
  description,
  granted,
  action,
}: {
  title: string;
  description: string;
  granted: boolean;
  action: React.ReactNode;
}) {
  return (
    <View style={styles.item}>
      <Text style={styles.itemTitle}>
        {granted ? '✓ ' : ''}
        {title}
      </Text>
      <Text style={styles.itemDescription}>{description}</Text>
      {granted ? <Text style={styles.grantedText}>ניתנה</Text> : action}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  content: { padding: theme.spacing.lg },
  title: {
    fontSize: theme.typography.title,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.textPrimary,
    textAlign: 'center',
    marginBottom: theme.spacing.md,
  },
  intro: {
    fontSize: theme.typography.body,
    color: theme.colors.textSecondary,
    textAlign: 'right',
    lineHeight: 24,
    marginBottom: theme.spacing.lg,
  },
  item: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },
  itemTitle: {
    fontSize: theme.typography.subtitle,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.textPrimary,
    textAlign: 'right',
  },
  itemDescription: {
    fontSize: theme.typography.caption,
    color: theme.colors.textSecondary,
    textAlign: 'right',
    marginTop: theme.spacing.xs,
    marginBottom: theme.spacing.sm,
    lineHeight: 20,
  },
  grantedText: {
    fontSize: theme.typography.caption,
    color: theme.colors.success,
    textAlign: 'right',
    fontWeight: theme.fontWeight.medium,
  },
  hint: {
    fontSize: theme.typography.caption,
    color: theme.colors.warning,
    textAlign: 'right',
    marginBottom: theme.spacing.sm,
    lineHeight: 20,
  },
  limitedBox: {
    backgroundColor: '#FFF3E0',
    borderRadius: theme.radius.md,
    padding: theme.spacing.md,
    marginTop: theme.spacing.sm,
  },
  limitedText: {
    fontSize: theme.typography.caption,
    color: theme.colors.warning,
    textAlign: 'right',
    lineHeight: 20,
  },
  footer: { padding: theme.spacing.lg },
});
