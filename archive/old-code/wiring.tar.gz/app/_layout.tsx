import React, { useEffect } from 'react';
import { Stack, router } from 'expo-router';
import * as Notifications from 'expo-notifications';
import { ensureRTL } from '../src/i18n/rtl';
import { trackEvent } from '../src/analytics/analyticsService';
import { AnalyticsEvent } from '../src/analytics/events';
import { theme } from '../src/theme';
import '../src/notifications/notificationService';
// חייב להיות ייבוא בשורה נפרדת ובלי שימוש: הוא רושם את משימות הרקע
// בזמן טעינת המודול, לפני שריאקט מרנדר. אם המערכת מעירה את האפליקציה
// לאירוע רקע והמשימה לא רשומה - האירוע פשוט הולך לאיבוד.
import '../src/services/backgroundTasks';
import * as protectionService from '../src/services/protectionService';

/**
 * לחיצה על התראה מעבירה למסך הרלוונטי (סעיף 14). התראות של תחילת נסיעה
 * ושל "שכחת לסיים" מסומנות target: 'active' ולכן מחזירות למסך הנסיעה
 * הפעילה - שם יש את הכפתור "סיים נסיעה". כל השאר מובילות לבדיקת הבטיחות.
 */
function openFromNotification(data: Record<string, unknown> | undefined) {
  // אזהרות ההגנה האוטומטית לא קשורות לנסיעה ידנית ואין להן tripId.
  if (data?.target === 'warning') {
    trackEvent(AnalyticsEvent.REMINDER_OPENED);
    router.push('/warning');
    return;
  }

  const tripId = data?.tripId;
  if (typeof tripId !== 'string' || !tripId) return;

  trackEvent(AnalyticsEvent.REMINDER_OPENED);
  if (data?.target === 'active') {
    router.push({ pathname: '/trip/active', params: { tripId } });
  } else {
    router.push({ pathname: '/trip/safety-check', params: { tripId } });
  }
}

export default function RootLayout() {
  useEffect(() => {
    ensureRTL();
    trackEvent(AnalyticsEvent.APP_OPENED);

    // התראה שנלחצת בזמן שהאפליקציה פתוחה/ברקע (סעיף 14 - לחיצה על התראה
    // מעבירה ישר ל-Safety Check).
    const responseSub = Notifications.addNotificationResponseReceivedListener((response) => {
      openFromNotification(response.notification.request.content.data);
    });

    // מקרה של פתיחת האפליקציה מאפס על ידי לחיצה על התראה (cold start).
    Notifications.getLastNotificationResponseAsync().then((response) => {
      openFromNotification(response?.notification.request.content.data);
    });

    // המודול הנייטיב רושם אירועים גם כשהאפליקציה סגורה. בפתיחה אנחנו
    // קוראים מה קרה בזמן שלא היינו - זה בדיוק המקרה של הורה שיצא מהרכב
    // והאפליקציה לא רצה.
    void protectionService.consumePendingVehicleEvent();

    // התראה שמגיעה בזמן שהאפליקציה פתוחה - לצורכי אנליטיקס בלבד.
    // נספרות רק תזכורות בדיקת הבטיחות, לא ההתראה של תחילת נסיעה.
    const receivedSub = Notifications.addNotificationReceivedListener((notification) => {
      if (notification.request.content.data?.target !== 'active') {
        trackEvent(AnalyticsEvent.REMINDER_SENT);
      }
    });

    return () => {
      responseSub.remove();
      receivedSub.remove();
    };
  }, []);

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: theme.colors.background },
      }}
    />
  );
}
